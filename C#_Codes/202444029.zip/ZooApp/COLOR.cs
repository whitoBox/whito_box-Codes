﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZooApp
{
    //ctrl + shift + u 선택된 택스트 대문자 변경
    enum COLOR
    {
        WHITE,
        BLACK,
        YELLOW,
        MIXED,

        END,
    }
}
